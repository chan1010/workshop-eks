<template>
    <div class="content">
      <vue3-flip-countdown countdownSize="5rem" mainColor="pink" deadline="2024-01-01 00:00:00"/>
    </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style lang="css" scoped>
@import url("https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100;0,200;0,300;0,400;0,500;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");
.content {
  display: flex;
  align-items: center;
  justify-content: center;
  height:100vh;
  width: 100vw;
  margin: -16px -16px;
}
</style>
